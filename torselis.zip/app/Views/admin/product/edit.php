<?= $this->extend('layout/admin_template'); ?>

<?= $this->section('content'); ?>
<div class="container text-center h-100">
    <h1 class="my-5">On process</h1>
</div>
<?= $this->endSection(); ?>