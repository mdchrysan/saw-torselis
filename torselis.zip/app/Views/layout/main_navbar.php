<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top shadow">
    <div class="container-fluid mx-5">
        <a class="navbar-brand" href="#"><i>T O R S E L I S</i></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMain" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- <div class="d-flex justify-content-end"></div> -->
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="<?= base_url('/'); ?>">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="#tentang">Tentang</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= base_url('/products/motor-listrik'); ?>">Produk</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= base_url('/login'); ?>">Login</a></li>
            </ul>
        </div>
    </div>
</nav>